<?php
session_start();
require 'functions.php'; 
?>
