<?php

return [
	'host' => 'localhost',
	'name' => 'proj',
	'user' => 'root',
	'password' => '',
];